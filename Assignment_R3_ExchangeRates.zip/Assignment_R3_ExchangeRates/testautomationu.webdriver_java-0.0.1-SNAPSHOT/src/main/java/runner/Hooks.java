package runner;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.BaseUtils;

public class Hooks extends BaseUtils {

		private BaseUtils base;
		
		public Hooks(BaseUtils base) {
			this.base = base;
		}
		
	@Before
	public void intializeRest(Scenario scenario) {
		
		scenarioDef = BaseUtils.features.createNode(scenario.getName());
		System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
    	driver = new ChromeDriver(); 
    	
	}
	
	@After
	public void tearDownTest(Scenario scenario) {
		if(scenario.isFailed()) {
			System.out.println(scenario.getName());
		}
		
		System.out.println("Closing Browser");
		driver.quit();
	}
}
