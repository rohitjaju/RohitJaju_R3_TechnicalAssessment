package utils;

import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ExtentHtmlReporterConfiguration;
import com.aventstack.extentreports.reporter.configuration.Theme;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.*;

public class ExtentReportsUtil extends BaseUtils{

	String fileName= reportLocation + "extentreport.html";
		
	public void ExtentReport() {
		//First is to create extent report
		extent= new ExtentReports();
		
			ExtentHtmlReporter htmlReporter= new ExtentHtmlReporter(fileName);
			htmlReporter.config().setTheme(Theme.STANDARD);
			htmlReporter.config().setDocumentTitle("Set Report For TestAutomation Applications");
			htmlReporter.config().setEncoding("utf-8");
			htmlReporter.config().setReportName("Test Report UI & API");
			
			//Attach Reporter
			extent.attachReporter(htmlReporter);
			
		}
	
	public void ExtentReportScreenshot() throws IOException {
		
		var src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(src.toPath(), new File(reportLocation+"screenshot.png").toPath());
		scenarioDef.fail("details").addScreencastFromPath(reportLocation+"screenshot.png");
		
	}
	
	public void FlushReport() {
		extent.flush();
	}
	
	
	
	
	
}