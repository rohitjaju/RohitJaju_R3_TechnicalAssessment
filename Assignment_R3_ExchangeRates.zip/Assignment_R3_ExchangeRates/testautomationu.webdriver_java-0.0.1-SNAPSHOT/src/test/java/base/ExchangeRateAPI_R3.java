package base;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import io.cucumber.java.en.When;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class ExchangeRateAPI_R3 {

	static Response response;

	@BeforeTest
	public void beforeTest() {
		RestAssured.baseURI = "https://open.er-api.com/v6/latest/USD";
		RequestSpecification httprequest = RestAssured.given();
		response = httprequest.request(Method.GET, "");
	}

	// validate response code,status,currency count in API
	@Test
	public void getRequestOpenEr_API() {
		System.out.println("The status received: " + response.statusLine());
		System.out.println("The response time is: " + response.getTimeIn(TimeUnit.SECONDS));
		int status_code = response.statusCode();
		System.out.println("The status received: "+status_code);

		// validate status code 200 OK
		Assert.assertEquals(status_code, HttpStatus.SC_OK);
		System.out.println("The response is as following: " + response.prettyPrint());

		JsonPath jsonPathEvaluator = response.jsonPath();
		String rates = jsonPathEvaluator.get("rates").toString();
		String[] arr = rates.split(",");
		int count = 0;
		for (String str : arr) {
			count++;
		}
		System.out.println("Total " + count + " -> currencies are present in API");

	}

	//validate range for the AED price
	@Test
	@When("User hit the exchange rate api and validates AED price range")
	public void validate_AED_range() {
		JsonPath jsonPathEvaluator = response.jsonPath();
		float lower = 3.6f;
		float upper = 3.7f;
		boolean flag = true;
		String rates_AED = jsonPathEvaluator.get("rates.AED").toString();
		System.out.println("#### AED Rate: " + rates_AED);
		Assert.assertEquals(rates_AED, "3.6725", "Failed : Correct rate NOT received in the response for USD Vs AED ");
		Assert.assertEquals(rates_AED, "3.6725");

		// validate range for the AED price
		float rates_AED_value = jsonPathEvaluator.get("rates.AED");
		if (rates_AED_value > lower && rates_AED_value < upper) {
			System.out.println("** AED currency rate :" + rates_AED_value + " is inside the correct range");
		} else {
			flag = false;
			System.out.println("** ERROR: AED currency rate:" + rates_AED_value + " is NOT in the given range");
			Assert.assertFalse(false);
			Assert.assertTrue(flag);
		}
	}

	//validate JSON schema from API contents
	@SuppressWarnings("deprecation")
	@Test
	public void validate_JSON_schema() throws IOException {
		String responseBody = response.getBody().asString();
		String expectedJson = FileUtils.readFileToString(new File(
				"D:\\Assignment_R3_ExchangeRates\\testautomationu.webdriver_java-0.0.1-SNAPSHOT\\src\\main\\java\\utils\\exchange_api_schema.json"));
		response.then().assertThat().body(matchesJsonSchema(expectedJson));
		//System.out.println("***Expected Json schema is :" + expectedJson);

	}
}
