package base;

import static org.testng.Assert.assertTrue;
import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import static io.restassured.RestAssured.given;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.minidev.json.JSONObject;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class Test_API {
	
	static Response response;
	
	/*public void postRequestBooksAPI()
	{ 
	   RestAssured.baseURI = "https://demoqa.com"; 
	   RequestSpecification request = RestAssured.given();
	   // JSONObject is a class that represents a Simple JSON. 
	   // We can add Key - Value pairs using the put method   
	   JSONObject requestParams = new JSONObject(); 
	   requestParams.put("userId", "TQ123"); 
	   requestParams.put("isbn", "9781449325862"); 
	   // Add a header stating the Request body is a JSON 
	   request.header("Content-Type", "application/json"); // Add the Json to the body of the request 
	   request.body(requestParams.toJSONString()); // Post the request and check the response
	   Response response = request.post("/BookStore/V1/Books"); 
	   System.out.println("The status received: " + response.statusLine());
	}
	
	*/
	
	@BeforeTest
	public void beforeTest()
	{ 
	RestAssured.baseURI ="https://open.er-api.com/v6/latest/USD";
    RequestSpecification httprequest = RestAssured.given();
    response = httprequest.request(Method.GET, "");
	}
	
	@Test
	public void getRequestOpenEr_API()
	{ 
	    //RestAssured.baseURI ="https://pro-api.coinmarketcap.com";
	    System.out.println("The status received: " + response.statusLine());
	    System.out.println("The response time is: " + response.getTimeIn(TimeUnit.SECONDS));
	    System.out.println("The status received: " + response.statusCode());
	    int status_code = response.statusCode();
	    
	    //validate status code 200 OK
	    Assert.assertEquals(status_code,HttpStatus.SC_OK);
	    System.out.println("The response is as following: " + response.prettyPrint());
	    
	    JsonPath jsonPathEvaluator = response.jsonPath();
	    String rates = jsonPathEvaluator.get("rates").toString();
	    String[] arr = rates.split(",");
	    int count=0;
	    for (String str : arr) {
	    	count++;
	    	}
	    System.out.println("Total " +count+" -> currencies are present in API");
	    
	} 
	    
	
	//validate range for the AED price
		@Test
		public void validate_AED_range() {
			JsonPath jsonPathEvaluator = response.jsonPath();
			float lower = 3.6f; 
			float upper = 3.7f;
			boolean flag= true;
			String rates_AED = jsonPathEvaluator.get("rates.AED").toString();
			System.out.println("####"+ rates_AED);
			Assert.assertEquals(rates_AED, "3.6725", "Failed:Correct rate NOT received in the Response for USD Vs AED ");
			Assert.assertEquals(rates_AED, "3.6725");
			
			//validate range for the AED price
			float rates_AED_value = jsonPathEvaluator.get("rates.AED");
			if(rates_AED_value>lower && rates_AED_value<upper ){
			       System.out.println("**rates_AED_value:"+rates_AED_value+" is inside the correct range");
			   }
			else {
				flag=false;
				System.out.println("ERROR: rates_AED_value:"+rates_AED_value+" is NOT inside the given range");
				Assert.assertFalse(false);
				Assert.assertTrue(flag);
			}
		}
		
		
		@SuppressWarnings("deprecation")
		@Test
		public void validate_JSON_schema() throws IOException {
        String responseBody = response.getBody().asString();
        //Assert.assertEquals(responseBody, JsonSchemaValidator.matchesJsonSchema("C:\\UI_Framework_Automation\\testautomationu.webdriver_java-0.0.1-SNAPSHOT\\target\\exchange_api_schema.json"));
	
        String expectedJson = FileUtils.readFileToString(new File("C:\\Assignment_CoinMarketCap\\testautomationu.webdriver_java-0.0.1-SNAPSHOT\\exchange_api_schema.json"));
        response.then().assertThat().body(matchesJsonSchema(expectedJson));
        System.out.println("***Expected Json schema is :" +expectedJson);
        
        
        
     
		
		
		
		}
		  

	
/*	public void postRequestBooksAPI1()
	{ 
	   RestAssured.baseURI = "https://demoqa.com"; 
	   RequestSpecification request = RestAssured.given();
	   // JSONObject is a class that represents a Simple JSON. 
	   // We can add Key - Value pairs using the put method   
	   JSONObject requestParams = new JSONObject(); 
	   requestParams.put("userId", "TQ123"); 
	   requestParams.put("isbn", "9781449325862"); 
	   // Add a header stating the Request body is a JSON 
	   request.header("Content-Type", "application/json"); // Add the Json to the body of the request 
	   request.body(requestParams.toJSONString()); // Post the request and check the response
	   Response response = request.post("/BookStore/V1/Books"); 
	   System.out.println("The status received: " + response.statusLine());
	}*/

	
   

}
